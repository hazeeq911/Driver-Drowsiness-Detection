# Driver Drowsiness Detection > 2022-08-10 6:11pm
https://universe.roboflow.com/object-detection/driver-drowsiness-detection-qstde

Provided by Roboflow
License: CC BY 4.0

